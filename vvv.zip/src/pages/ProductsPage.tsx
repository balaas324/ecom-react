export default function ProductsPage() {
  return <div className="p-4 text-xl font-bold">Products</div>
}
